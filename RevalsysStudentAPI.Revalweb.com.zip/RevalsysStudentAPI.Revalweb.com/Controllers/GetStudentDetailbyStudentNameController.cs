﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Revalsys.Student.BAL;
using Revalsys.Student.RevalCommon;
using Revalsys.Student.RevalProperties;
using System.Net.Mime;

namespace RevalsysStudentAPI.Revalweb.com.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetStudentDetailbyStudentNameController : ControllerBase
    {
        private ConfigurationSettingsListDTO _ConfigurationSettingsListDTO = null;

        public GetStudentDetailbyStudentNameController(IOptions<ConfigurationSettingsListDTO> options)
        {
            _ConfigurationSettingsListDTO = options.Value;
        }

        [HttpPost]

        public async Task<ContentResult> GetStudentDetail(StudentListDTO objStudentListDTO)
        {
            string headerType = Request.ContentType;
            ContentResult contentResult = new ContentResult();
            object response = null;
            int statusCode = 0;
            int ReturnCode = 0;
            string StrReturnMessage = string.Empty;
            APIResponseListDTO objAPIResponse = new APIResponseListDTO();
            StudentBAL objStudentBAL = null;

            try
            {
                objStudentBAL = new StudentBAL(_ConfigurationSettingsListDTO);

                objAPIResponse = await objStudentBAL.GetStudentDetailsAsync(objStudentListDTO);
            }
            catch (Exception ex)
            {
                ReturnCode = Convert.ToInt32(General.ResponseCodes.InternalError);
                StrReturnMessage = ex.Message;
                objAPIResponse = new APIResponseListDTO()
                {
                    ReturnCode = ReturnCode,
                    ReturnMessage = StrReturnMessage

                };

            }
            finally
            {

            }

            if (objAPIResponse != null)
            {
                if (headerType != null && headerType.ToLower().Contains("application/json")) 
                {
                    contentResult = new ContentResult()
                    {
                        Content = JsonConvert.SerializeObject(objAPIResponse),
                        ContentType = "application/json",
                        StatusCode = statusCode
                    };
                }
                else
                {
                    contentResult = new ContentResult()
                    {
                        Content = JsonConvert.SerializeObject(objAPIResponse),
                        ContentType = "application/json",
                        StatusCode = statusCode
                    };
                }
                return contentResult;
            }
            else
            {
                return new ContentResult()
                {
                    Content = "No data found",
                    ContentType = "application/json",
                    StatusCode = 404
                };
            }
        }
    }
}
