﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Revalsys.Student.BAL;
using Revalsys.Student.RevalCommon;
using Revalsys.Student.RevalProperties;

namespace RevalsysStudentAPI.Revalweb.com.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InsertStudentDetailController : ControllerBase
    {
        private ConfigurationSettingsListDTO _ConfigurationSettingsListDTO = null;

        public InsertStudentDetailController(IOptions<ConfigurationSettingsListDTO> options)
        {
            _ConfigurationSettingsListDTO = options.Value;
        }


        [HttpPost]
        public async Task<ContentResult> InsertStudentDetail(StudentDataListDTO objStudentDetailListDTO)
        {
            string headerType = Request.ContentType;
            ContentResult contentResult = new ContentResult();
            int statusCode = 0;
            int ReturnCode = 0;
            string StrReturnMessage = string.Empty;
            APIResponseListDTO objAPIResponse = new APIResponseListDTO();
            StudentBAL objStudentBAL = null;

            try
            {
                if (objStudentDetailListDTO == null)
                {
                    ReturnCode = (int)General.ResponseCodes.Failure;
                    StrReturnMessage = "Student details not provided.";
                    objAPIResponse = new APIResponseListDTO()
                    {
                        ReturnCode = ReturnCode,
                        ReturnMessage = StrReturnMessage
                    };
                }
                else
                {
                    objStudentBAL = new StudentBAL(_ConfigurationSettingsListDTO);
                    objAPIResponse = await objStudentBAL.InsertStudentDetailAsync(objStudentDetailListDTO);
                }

            }
            catch (Exception ex)
            {

                ReturnCode = Convert.ToInt32(General.ResponseCodes.InternalError);
                StrReturnMessage = ex.Message;
                objAPIResponse = new APIResponseListDTO()
                {
                    ReturnCode = ReturnCode,
                    ReturnMessage = StrReturnMessage
                };
            }


            if (objAPIResponse != null)
            {
                contentResult = new ContentResult()
                {
                    Content = JsonConvert.SerializeObject(objAPIResponse),
                    ContentType = "application/json",
                    StatusCode = statusCode
                };
            }
            else
            {

                contentResult = new ContentResult()
                {
                    Content = "No data found",
                    ContentType = "application/json",
                    StatusCode = 404
                };
            }

            return contentResult;
        }
    }
}
